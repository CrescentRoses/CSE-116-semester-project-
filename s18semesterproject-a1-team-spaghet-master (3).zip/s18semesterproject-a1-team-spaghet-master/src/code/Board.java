package code;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;

public class Board{
   /**
    * These are identification numbers.
    */
        private static final int Assassin = 0;
        private static final int Red = 1;
        private static final int Blue = 2;
        private static final int IC = 3;
        private static final int Green = 4;
	//private static final int Assassin2 = 5;
		
   /**
    * Feature #2 [6 points]<br>
    * Defines a Board class contains 25 Location instances.
    * Array in which 25 Location instances are stored.
    */
	private Location[][] locations;
	
   /**
    * ArrayList which stores all codenames read from "GameWords.txt".
    */
	private ArrayList<String> allCodeNames;
	
   /**
    * ArrayLsit which stores 25 distinct codenames selected at random.
    */
	private ArrayList<String> codeNames;

   /**
    * ArrayList which stores randomly generated assignments for each of the 9 Red Agents, 8 Blue Agents, 
    * 7 Innocent Bystanders, and 1 Assassin.
    */
	private ArrayList<Integer> personList;
	
   /**
    * red tesam's turn = true. blue team's turn = false. Red teams turn first.
    */	
	private boolean turn;
	
   /** Indicate whether it is in green team's turn. It implies whether the game is 2-team version or 3-team version. */
	private boolean greenTurn;
	
	/**
	 * Indicate whether we have green team or not;
	 */
	private boolean hasGreen;
	
   /**
    * <ul>
    *   <li>0 no winner, no loser</li>
	*	<li>1 red team wins </li>
	*   <li>2 blue team wins</li>
	*	<li>3 green team wins  </li>
	*	<li>4 red team loses, no winner, turn is always false</li>
	*	<li>5 blue team loses, no winner, turn always true</li>
	*	<li>6 green team loses, no winner, greenTurn always false</li>
	*	<li>7 assassins revealed, red win</li>
	*	<li>8 assassins revealed, blue win</li>
	*	<li>9 assassins revealeed, green win</li>
	* </ul>
    */
	private int status;	

   /**
    * The number agents that had been revealed. 
    */
	private int redCount;
	
   /**
    * The number agents that had been revealed. 
    */
	private int blueCount;
	
   /**
    * The number agents that had been revealed. 
    */
	private int greenCount;
   
   /** Indicate which team reveals the first assassin. It has default value 0 (no team reveal Assassin), {@link#Red}, {@link#Blue} and {@link#Green} */
	private int teamFirstOut;
		
   /**
    * clue is a string provided by spymaster.
    */
	private String clue;
	
   /**
    * count is an integer provided by spymaster.
    */
	private int count;

   /**
    * Constructor of a board, it initialize everything
    */
	public Board() {
		turn = true;  //Red team starts first
		greenTurn = false;
		status = 0;
		redCount = 0;			
		blueCount = 0;
		greenCount = 0;
		clue ="";
	}
			
    /**
     * Reads codenames from the file named "names.txt" and stores them in allCodeNames field
     * 
     * @param filename - the name of file from which codenames are read
     * @return an ArrayList which stores all codenames read from a given file 
     */
	 public ArrayList<String> readCodeNames(String filename){// throws IllegalArgumentException{
		 allCodeNames = new ArrayList<String>();
		 if(filename != null) {
			 try {
				 for(String line : Files.readAllLines(Paths.get(filename))){// List with repeating names
					 allCodeNames.add(line);
				  }
				 } 
			 catch (IOException e) {
				 System.out.println(e);
			 }
		 }
		 else {
			 throw new IllegalArgumentException("filename is null!");
		 }
		 return allCodeNames;		 
	 }


    /**
     * Creates a List containing 25 distinct codenames selected at random from allCodeNames and stores it in codeNames field

     * @param filename - the name of file from which codenames are read
     * @return an ArrayList which stores created 25 codenames generated from allCodeNames 
     */
	 public ArrayList<String> createCodeName(String filename){// throws IllegalArgumentException{
		 codeNames = new ArrayList<String>();
			 readCodeNames(filename);
			 if(allCodeNames.size() > 0 && allCodeNames.size() < 25) {               
				 throw new IllegalArgumentException("File should contains at least 25 codenames!");
			 }
			 else if(allCodeNames.size() >= 25) {
				 Collections.shuffle(allCodeNames);// shuffle
				 for (int i = 0; i < 25; i++) {
					 codeNames.add(allCodeNames.get(i));
				 }
			 }
			 else {
				 throw new IllegalArgumentException("File does not exist.");
			 }
		 return codeNames;
	 }

    /**
     * Creates List containing randomly generated assignments for each of the 9 Red Agents, 8 Blue Agents,
     * 7 Innocent Bystanders, and 1 Assassin, and stores it in assignments field
     * 
     * @return an ArrayList which stores 25 persons generated randomly
     */
	 public ArrayList<Integer> personList() {
		personList = new ArrayList<Integer>();
		
		if(hasGreen == false) {
			
			for(int i = 0; i < 8; i++) {
				personList.add(Blue);
			}
			for(int i = 0; i < 9; i++) {
				personList.add(Red);
			}
			for(int i = 0; i < 7; i++) {
				personList.add(IC);
			}
			
			personList.add(Assassin);			
			Collections.shuffle(personList);
			return personList;
			
		}else {
		
			for(int i = 0; i < 5; i++) {
				personList.add(Blue);
				personList.add(Green);
			}
			for(int i = 0; i < 6; i++) {
				personList.add(Red);
			}
			for(int i = 0; i < 7; i++) {
				personList.add(IC);
			}
			
			personList.add(Assassin);
			personList.add(Assassin);
			Collections.shuffle(personList);
			return personList;
		 }
	 }		
	 
    /**
     * Starts a new game, set "Red" team to move first. Each of Board's 25 Location instances is assigned a codename,
     * Person, and is Not Revealed
     * 
     * @param filename - the name of file from which codenames are read.
     * @param version - true means 2-teams version, false means 3-teams version.
     */
	 public void initialize(String filename, Boolean version) {
		 hasGreen = !version; 
		 teamFirstOut = version? Green : 0;
		 createCodeName(filename);
		 personList();
		 int x = 0;
		 locations = new Location[5][5];
		 for(int i = 0; i < 5; i++) {
			 for(int j = 0; j < 5; j++) {
				locations[i][j] = new Location(codeNames.get(x), personList.get(x));
				x++;
			}
		}
	}		
    /**
     * Returns if a clue is legal or illegal (clues cannot equal a current codename unless that codename is in 
     * a locations that was already Revealed). If it is illegal, the team's turn is forfeit
     * 
     * @param clue - information provided by spymaster
     * @return whether a clue is legal or illegal
     */
	 public boolean checkClue(String clue) {
		 if(clue == null || clue.length() == 0)
			 return false;
		 for(int i = 0; i < locations.length; i++) {
			for(int j = 0; j < locations.length; j++) {
		                if(!locations[i][j].getfound() && clue.toLowerCase().equals(locations[i][j].getCodename().toLowerCase())) {
					return false;
				}
			}
		 }
		 return true;
	}

   /**
    * Returns if the Location revealed belongs to the current team's Agent
    * Does a series of actions after a location is revealed, including decrementing the count, updating a Location 
    * when the Location's codename was selected
    * 
    * @param  row - the row index of revealed location
    * @param  col - the column index of revealed location 
    * @return The person identity located at the revealed location
    */
	 public int revealALocation(int row, int col) {
		Location loc = locations[row][col];
		loc.chnagefound();   // is revealed
		if(loc.getId() == Assassin) {
			revealAssassin();
			return Assassin;
		}
		else if(loc.getId() == Red) {
			redCount++;
			if(turn && !greenTurn) {
				count--;
				ifCountBelowZero();
			} else {
				changeTurn();
			}
			return Red;
		}
		else if(loc.getId() == Blue) {
			blueCount++;
			if(!turn && !greenTurn) {
				count--;
				ifCountBelowZero();
			} else {
				changeTurn();
			}
			return Blue;
		}
		else if(loc.getId() == Green) {
			greenCount++;
			if(greenTurn) {
				count--;
				ifCountBelowZero();
			}else {
				changeTurn();
			}
			return Green;
		}
		else {
			changeTurn();
			return IC;
		}
	}
	 
   /**
    * Method which correctly returns whether or not the Board is in one of the winning states
    * 	     
    * @return the status of the Board
    */
	public int checkBoardState() {
		// Assassin statuses 
		if(status == 7 || status == 8 || status == 9) 
			return status;
		
		//red teams wins 
		else if(hasGreen && teamFirstOut != Red && redCount == 6 || !hasGreen && redCount == 9) {
			status = 1;
		}
		
		// blue team wins by revealing all its agents
		else if(hasGreen && teamFirstOut != Blue &&  blueCount == 5 || !hasGreen && blueCount == 8)
			status = 2;
		
		// green team wins by revealing all the agents
		else if (teamFirstOut != Green && greenCount ==5) {
			status = 3;
		}
		
		return status;
	}
	 /**
	    * This method changes status after a assassin is reavealed, and switch game's turn.
	    *  	     
	    * @return team first out when the first assassin is revealed;<br>
	    *         which team wins when the second assassin is revealed.
	    */
		public int revealAssassin() {
			if(hasGreen) {
				if(getStatus() == 0) {
					status = greenTurn? 6 : turn? 4 : 5;
					teamFirstOut = greenTurn? Green : turn? Red : Blue;
					changeTurn();		
					return teamFirstOut;
				}
				else {
					if(status == 6) {
						status = turn? 8 : 7;
					    return turn? Blue : Red;
					}else if(status == 5) {
						status = greenTurn? 7 : 9;
						return greenTurn? Red : Green;
						}
					else /*(status == 4)*/ {
						status = greenTurn? 8 : 9;
						return greenTurn? Blue : Green;
						}
				}
			}
			else {
				status = turn? 8 : 7;
				return turn? Blue : Red;
			}
			
		}
	 
   /**
    * Stores the clue and count provided by "Skymaster" to clueCount field
    * 	
    * @param clue - string information provided by spymaster
    * @param count - integer information provided by spymaster
    */
	 public void setClueAndCount(String clue, int count) {
		 if(clue == null)
			 throw new IllegalArgumentException("The clue should not be null.");
		 this.clue = clue;
		 
		 if(count < 0 || count > 25) {
			 throw new IllegalArgumentException("The count should in (0,25].");
		 }
		 this.count = count;
	 }
	 
   /**
    * 
    */
	public void ifCountBelowZero() {
		if(count < 0)
			changeTurn();
	}	
	
   /**
    * This method changes the turn
    */
	public void changeTurn() {
		// there are three teams
		if(turn && !greenTurn)
			turn = !turn;
		else if(!turn && !greenTurn) {
			turn = !turn;
			greenTurn = true;
		}
		else {
			greenTurn = false;
		}
		// there are two teams
		if(teamFirstOut == Red)
			turn = false;
		else if(teamFirstOut == Blue) {
			if(turn == false)
				greenTurn = true;
			turn = true;
		}
		else if(teamFirstOut == Green)
			greenTurn = false;
	}
	
   /** 
    *  This method return the status of our game;
    *  
    *  @return {@link #status}.
    */	
	public int getStatus() {
		return status;
	}
		
   /** 
    *  This method return the redCount of our game;
    *  
    *  @return redCount - the number of red agents that has been found.
    */	
	public int getRedcount() {
		return redCount;
	}
		
   /** 
    *  This method return the blueCount of our game;
    *  
    *  @return blueCount - the number of blue agents that has been found.
    */	
	public int getBluecount() {
		return blueCount;
	}   
	
   /** 
    *  This method return the blueCount of our game;
    *  
    *  @return blueCount - the number of blue agents that has been found.
    */	
	public int getGreencount() {
		return greenCount;
	}
		
   /** 
    *  This method return the turn of our game;
    *  
    *  @return turn
    */	
	public boolean getTurn() {
		return turn;
	}
	  
   /** 
    *  This method return the turn of our game;
    *  	   
	*  @return turn
    */	
	public boolean getGreenTurn() {
		return greenTurn;
	}
	
		
   /** 
    *  This method return the count of our game;
    *  
    *  @return count - a int number provide by spymaster.
    */	
	public int getCount() {
		return count;
	}

   /** 
    *  This method return the 25 locations;
    *  	 
    *  @return location[][] - 25 location instances in board.
    */	
	public Location[][] getlocations() {
		return locations;
	}	
	
   /** 
    *  This method set locations, which is designed for testing
    *
    *  @param locs - 25 location instances in board.
    */
	public void setLocations(Location[][] locs) {
		locations = locs;
	}
	
   /** 
    *  This method set locations, which is designed for testing
    *  
    *  @return personList , a List contains ID information in board.
    */
	public ArrayList<Integer> getPersonList(){
		return personList;
	}
	
   /** 
    *  This method set locations, which is designed for testing
    *
    *  @return String - refers to the clue provided by skymaster.
    */
	public String getClue() {
		return clue;
	}

	/** 
	 *  This method set Statu, which is designed for test and easter egg.
	 */
	public void setStatu(int i) {
	    status = i;
	}
	
	/** 
	 *  This method set teamFirstOut, which is designed for test.
	 */
	public void setTeamFirstOut(int team) {
		teamFirstOut = team;
	}
	
	/**
	 * This method set hasGreen valuable.
	 * @param b {@code true} If we have green team, {@code false} otherwise.
	 */
	public void setGreen(boolean b) {
		hasGreen = b;
	}
	
	/**
	 * This method return hasGreen valuable.
	 * 
	 * @return whether we have green team or not.
	 */
	public boolean getHasGreen() {
		return hasGreen;
	}
}


