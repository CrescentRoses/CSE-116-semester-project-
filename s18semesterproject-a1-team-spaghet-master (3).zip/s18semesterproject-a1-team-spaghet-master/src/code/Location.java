package code;

public class Location {
	
	private int _id; //NEW 
	private String _codename;
	private boolean _found;

		//New
		public Location (String codename, int id) {
			_codename = codename;
			_id = id;
			_found = false;
		}
		
		public String getCodename () {
			return this._codename;
		}
		 
		public boolean getfound() {
			return _found;
		}
		public boolean chnagefound() {
			if ( _found == false) {
				_found = true;
			}
			return _found;
		}
		public int getId() {
			return _id;
		}
}
