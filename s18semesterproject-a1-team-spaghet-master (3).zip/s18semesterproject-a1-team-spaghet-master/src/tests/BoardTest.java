package tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import code.Location;
import code.Board;

public class BoardTest 
{
	
    protected Board board;
    private static final int Assassin = 0;
    private static final int Red = 1;
    private static final int Blue = 2;
    private static final int IC = 3;
    private static final int Green = 4;
	
	// used for testing revealALocation()
    public Location[][] initializeFor2TeamTest() {
 		ArrayList<Integer> personList = new ArrayList<Integer>();
 		for(int i = 0; i < 8; i++) {
 			personList.add(Blue);
 		}
 		for(int i = 0; i < 9; i++) {
 			personList.add(Red);
 		}
 		for(int i = 0; i < 7; i++) {
 			personList.add(IC);
 		}
 		personList.add(Assassin);
 		Location[][] locations = new Location[5][5];
 		int x = 0;
 		for(int i = 0; i < 5; i++) {
 			for(int j = 0; j < 5; j++) {
 				locations[i][j] = new Location(""+i, personList.get(x));
 				x++;
 			}
 		}
 		return locations;
     }
    
    public Location[][] initializeFor3TeamTest() {
 		ArrayList<Integer> personList = new ArrayList<Integer>();
 		for(int i = 0; i < 5; i++) {
 			personList.add(Blue);
 		}
 		for(int i = 0; i < 5; i++) {
 			personList.add(Green);
 		}
 		for(int i = 0; i < 6; i++) {
 			personList.add(Red);
 		}
 		for(int i = 0; i < 7; i++) {
 			personList.add(IC);
 		}
 		personList.add(Assassin);
 		personList.add(Assassin);
 		Location[][] locations = new Location[5][5];
 		int x = 0;
 		for(int i = 0; i < 5; i++) {
 			for(int j = 0; j < 5; j++) {
 				locations[i][j] = new Location(""+i, personList.get(x));
 				x++;
 			}
 		}
 		return locations;
     }
    
    @Before
    public void beforeAllTest() {
        board = new Board();
    }
	
	@Test (expected = IllegalArgumentException.class)
	public void readCodeNamesNullTest()
	{
		assertEquals("Should throw IllegalArgumentException when file name is 'null'!", 0, board.readCodeNames(null).size());
	}
	
	@Test
	public void readCodeNamesNoFileTest()
	{
		assertEquals(0, board.readCodeNames("NoSuchFile").size());	
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void createCodeNameNullNameTest()
	{
		assertEquals("Should throw IllegalArgumentException when file name is 'null'!", 0, board.createCodeName(null).size());
	}	
	
	@Test (expected = IllegalArgumentException.class)
	public void createCodeNameNoFileTest()
	{
		assertEquals(0, board.createCodeName("NoSuchFile").size());	
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void createCodeNameLess25Test()
	{		
		assertEquals(0, board.createCodeName("src/smallnames.txt").size());
	}
	
	@Test
	public void createCodeNameTest()
	{		
		assertEquals("We should have 25 codenames here in the arraylist!", 25, board.createCodeName("src/names.txt").size());
	}		
	
	@Test 
	public void personlistTest2Team() {
		int blueCount = 0;
		int redCount = 0;
		int assassinCount = 0;
		int ICCount = 0;
		assertEquals(25, board.personList().size());
		for(int x : board.getPersonList()) {   
			if(x == Blue) {
				blueCount++;
			}
			else if(x == Red) {
				redCount++;
			}
			else if(x == Assassin) {
				assassinCount++;
			}
			else {
				ICCount++;
			}
		}
		assertEquals("We should have 8 blue agents.", 8, blueCount);
		assertEquals("We should have 9 red agents.", 9, redCount);
		assertEquals("We should have 1 assassin.",1, assassinCount);
		assertEquals("We should have 7 innocent bystanders.", 7, ICCount);
	}
	
	@Test (expected =IllegalArgumentException.class )
	public void initializeNullTest()
	{
		board.initialize(null,true);
		assertEquals("Should throw IllegalArgumentException when file name is 'null'!", 0, board.getlocations().length);
	}

	@Test (expected = IllegalArgumentException.class)
	public void initializeNoFileTest()
	{	
		board.initialize("NoSuchFile",true);
		assertEquals(0, board.getlocations().length);
	}
	
	@Test
	public void initializeTest2Team()
	{	
		int locationCount = 0;
		int blueCount = 0;
		int redCount = 0;
		int assassinCount = 0;
		int ICCount = 0;
		board.initialize("src/names.txt",true);
		for(int i = 0; i < board.getlocations().length; i++) {
			for(int j = 0; j < board.getlocations()[i].length; j++) {
				locationCount++;
				assertEquals("All Location's _found should be assigned to false at the beginning!", false, board.getlocations()[i][j].getfound());
				if(board.getlocations()[i][j].getId() == Blue) {
					blueCount++;
				}
				else if(board.getlocations()[i][j].getId() == Red) {
					redCount++;
				}
				else if(board.getlocations()[i][j].getId() == Assassin) {
					assassinCount++;
				}
				else {
					ICCount++;
				}
			}
		}
		assertEquals("We should have 25 Location Objects in total", 25, locationCount);
		assertEquals("We should have 8 blue agents.", 8, blueCount);
		assertEquals("We should have 9 red agents.", 9, redCount);
		assertEquals("We should have 1 assassin.",1, assassinCount);
		assertEquals("We should have 7 innocent bystanders.", 7, ICCount);
	}
	
	@Test
	public void checkClueLegalTest01() {
		board.initialize("src/names.txt",true);
		assertTrue(board.checkClue("ilegalclue"));
	}
	
	@Test
	public void checkClueLegalTest02() {
		board.initialize("src/names.txt",true);
		board.revealALocation(0,0);
		assertTrue(board.checkClue(board.getlocations()[0][0].getCodename()));
	}
	
	@Test
	public void checkClueIllegalTest01() {
		board.initialize("src/names.txt",true);
		Location loc = board.getlocations()[0][0];
		assertFalse(board.checkClue(loc.getCodename()));
	}
	
	@Test
	public void checkClueIllegalTest02() {
		board.initialize("src/names.txt",true);
		assertFalse(board.checkClue(null));
	}
	
	@Test
	public void checkClueIllegalTest03() {
		board.initialize("src/names.txt",true);
		assertFalse(board.checkClue(""));
	}

    @Test
	public void revealALocation2TeamTest01() {
    	board.initialize("src/names.txt", true);
    	Location[][] locs = initializeFor2TeamTest();
		board.setLocations(locs);
        board.setClueAndCount("", 25);
        
		assertEquals(Blue,board.revealALocation(0,0)); // turn: red team. reveal blue
		assertFalse(board.getTurn()); // turn: blue
		assertTrue(board.getlocations()[0][0].getfound()); // test whether the _found of revealed location is updated
		assertEquals(1,board.getBluecount()); // test whether or not the blueCount is updated
		
		assertEquals(Red,board.revealALocation(2,0)); // turn: blue team. reveal red
		assertTrue(board.getTurn()); // turn: red
		assertEquals(1,board.getRedcount()); // test whether or not the redCount is updated
		
		assertEquals(Red,board.revealALocation(2,0)); // turn: red team. reveal red
		assertTrue(board.getTurn());  // turn: red
		assertEquals(IC,board.revealALocation(4,0)); // turn: red team. reveal innocent
		assertFalse(board.getTurn());  // turn: blue
		assertEquals(Blue,board.revealALocation(0,1)); // turn: blue team. reveal blue
		assertFalse(board.getTurn());  // turn: blue
		assertEquals(IC,board.revealALocation(4,1)); // turn: blue team. reveal innocent
		assertTrue(board.getTurn());  // turn: red
		assertEquals(Assassin,board.revealALocation(4,4)); // turn: red team. reveal assassin
    }
    
	@Test
	public void revealALocation2TeamTest02() {
    	board.initialize("src/names.txt", true);
		Location[][] locs = initializeFor2TeamTest();
		board.setLocations(locs);
		assertEquals(Blue,board.revealALocation(0,0)); // turn: red team. reveal blue
		assertFalse(board.getTurn());  // turn: blue
		assertEquals(Assassin,board.revealALocation(4,4)); // turn: blue team. reveal assassin
	}
	
    @Test
	public void revealALocation3TeamTest01() {
    	board.initialize("src/names.txt", false);
    	Location[][] locs = initializeFor3TeamTest();
		board.setLocations(locs);
        board.setClueAndCount("", 25);
        board.setGreen(true);
        
		assertEquals(Blue,board.revealALocation(0,0)); // turn: red team. reveal blue
		assertFalse(board.getTurn());
		assertFalse(board.getGreenTurn());  // turn: blue
		assertTrue(board.getlocations()[0][0].getfound()); // test whether the _found of revealed location is updated
		assertEquals(1,board.getBluecount()); // test whether or not the blueCount is updated
		
		assertEquals(Red,board.revealALocation(2,0)); // turn: blue team. reveal red
		assertTrue(board.getGreenTurn()); // turn: green 
		assertEquals(1,board.getRedcount()); // test whether or not the redCount is updated
		
		assertEquals(Red,board.revealALocation(2,1)); // turn: green team. reveal red
		assertTrue(board.getTurn());
		assertFalse(board.getGreenTurn());  // turn: red
		
		assertEquals(Red,board.revealALocation(2,2)); // turn: red team. reveal red
		assertTrue(board.getTurn());
		assertFalse(board.getGreenTurn());  // turn: blue
		
		assertEquals(IC,board.revealALocation(4,0)); // turn: red team. reveal innocent
		assertFalse(board.getTurn());
		assertFalse(board.getGreenTurn());  // turn: blue
		
		assertEquals(Blue,board.revealALocation(0,1)); // turn: blue team. reveal blue
		assertFalse(board.getTurn());
		assertFalse(board.getGreenTurn());  // turn: blue
		
		assertEquals(Green,board.revealALocation(1,1)); // turn: blue team. reveal green
		assertTrue(board.getGreenTurn());  // turn: green
		assertEquals(1,board.getGreencount()); // test whether or not the greenCount is updated
		
		assertEquals(Green,board.revealALocation(1,2)); // turn: green team. reveal green
		assertTrue(board.getGreenTurn());  // turn: green
		
		assertEquals(Assassin,board.revealALocation(4,4)); // turn: green team. reveal assassin
    }
	
	@Test
	public void testBoardStatus2Team1()
	{
    	board.initialize("src/names.txt", true);
		Location[][] test = initializeFor2TeamTest();
		board.setLocations(test);
		board.checkBoardState();
		assertEquals(0, board.getStatus());
		for(int i = 0; i < 5; i++) {
			board.revealALocation(0,i);
		}
		for(int i = 0; i < 3; i++) {
			board.revealALocation(1,i);
		}
		board.checkBoardState();
		assertEquals(2, board.getStatus());
	}
	
	@Test
	public void testBoardStatus2Team2()
	{
    	board.initialize("src/names.txt", true);
		Location[][] test = initializeFor2TeamTest();
		board.setLocations(test);
		board.revealAssassin();
		board.checkBoardState();
		assertEquals(8, board.getStatus());	// blue win
	}
	
	@Test
	public void testBoardStatus3Team1()
	{
    	board.initialize("src/names.txt", false);
		Location[][] test = initializeFor3TeamTest();
		board.setLocations(test);
		for(int i = 0; i < 5; i++) {
			board.revealALocation(0,i);
		}
		assertEquals(2, board.checkBoardState());	// blue win
	}
	
	@Test
	public void testBoardStatus3Team2()
	{
    	board.initialize("src/names.txt", false);
		Location[][] test = initializeFor3TeamTest();
		board.setLocations(test);
		board.revealALocation(4, 4);
		assertEquals(4, board.checkBoardState());	// blue win
	}
	
	@Test
	public void testBoardStatus3Team3()
	{
    	board.initialize("src/names.txt", false);
		Location[][] test = initializeFor3TeamTest();
		board.setLocations(test);
		board.revealALocation(4, 4);
		assertEquals(4, board.checkBoardState());	// red lose
		for(int i = 0; i < 5; i++) {
			board.revealALocation(2,i);
		}
		board.revealALocation(3,0);
		for(int i = 0; i < 5; i++) {
			board.revealALocation(1,i);
		}
		assertEquals(3, board.checkBoardState());	// green win
	}
	
	@Test
	public void testBoardStatus3Team5()
	{
    	board.initialize("src/names.txt", false);
		Location[][] test = initializeFor3TeamTest();
		board.setLocations(test);
		board.changeTurn();
		board.revealALocation(4, 4);
		assertEquals(5, board.checkBoardState());	// blue lose
		for(int i = 0; i < 5; i++) {
			board.revealALocation(0,i);
		}
		for(int i = 0; i < 5; i++) {
			board.revealALocation(1,i);
		}
		assertEquals(3, board.checkBoardState());	// green win
	}
	
	@Test
	public void testBoardStatus3Team6()
	{
    	board.initialize("src/names.txt", false);
		Location[][] test = initializeFor3TeamTest();
		board.setLocations(test);
		board.changeTurn();
		board.changeTurn();
		board.revealALocation(4, 4);
		assertEquals(6, board.checkBoardState());	// green lose
		for(int i = 0; i < 5; i++) {
			board.revealALocation(1,i);
		}
		for(int i = 0; i < 5; i++) {
			board.revealALocation(0,i);
		}
		assertEquals(2, board.checkBoardState());	// blue win
	}
	
	@Test
	public void testBoardStatus3Team4()
	{
    	board.initialize("src/names.txt", false);
		Location[][] test = initializeFor3TeamTest();
		board.setLocations(test);
		board.revealALocation(4, 4);
		board.revealALocation(4, 3);
		assertEquals(9, board.checkBoardState());	// green win
	}

	@Test (expected = IllegalArgumentException.class)
	public void setClueAndCountNullTest() {
		board.setClueAndCount(null, 1);
		assertEquals(null,board.getClue());
		assertEquals(1,board.getCount());
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void setClueAndCountNegativeTest() {
		board.setClueAndCount("", -1);
		assertEquals("",board.getClue());
		assertEquals(0,board.getCount());
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void setClueAndCountGreaterThan25Test() {
		board.setClueAndCount("", 30);
		assertEquals("",board.getClue());
		assertEquals(0,board.getCount());
	}
	
	@Test
	public void setClueAndCountTest() {
		board.setClueAndCount("", 1);
		assertEquals("",board.getClue());
		assertEquals(1,board.getCount());
	}
	
	@Test
	public void testGetStatus2Team()
	{
		int status = board.getStatus();
		assertEquals(0,status);	
	}
	
	@Test 
	public void testrevelAssassin2Team() {
		boolean found = false;
		board.initialize("src/names.txt",true);
		if(board.getStatus() == 7 || board.getStatus() == 8) {
			found = true;
		}
		else {
			found = false;
	    }
		assertFalse(found);// Red team finds assassin and lsoes
		
		assertEquals(Blue,board.revealAssassin());
		if(board.getStatus() == 7 || board.getStatus() == 8) {
			found = true;
		}
		else {
			found = false;
		}
		assertTrue(found);
		assertEquals(8,board.getStatus());
		board.initialize("src/names.txt",true);
		board.changeTurn();
		assertEquals(Red,board.revealAssassin());
		assertEquals(7,board.getStatus());		
	}
	
	@Test 
	public void testrevelAssassin3Team() {
		board.initialize("src/names.txt",false);
		assertEquals(0, board.getStatus());
		
		assertEquals(Red,board.revealAssassin());
		assertEquals(4, board.getStatus());
		assertFalse(board.getTurn());
		assertFalse(board.getGreenTurn());		
		assertEquals(Green,board.revealAssassin());
		assertEquals(9, board.getStatus());
		
		board = new Board();
		board.initialize("src/names.txt",false);
		board.changeTurn();
		assertEquals(Blue,board.revealAssassin());
		assertEquals(5, board.getStatus());
		assertTrue(board.getTurn());
		assertTrue(board.getGreenTurn());	
		assertEquals(Red,board.revealAssassin());
		assertEquals(7, board.getStatus());
		
		board = new Board();
		board.initialize("src/names.txt",false);
		board.changeTurn();
		board.changeTurn();
		assertEquals(Green,board.revealAssassin());
		assertEquals(6, board.getStatus());
		assertTrue(board.getTurn());
		assertFalse(board.getGreenTurn());	
		assertEquals(Blue,board.revealAssassin());
		assertEquals(8, board.getStatus());	
	}
	@Test
	public void changeTurnTest2Team() {
    	board.initialize("src/names.txt", true);
		assertFalse(board.getGreenTurn());
		assertTrue(board.getTurn());
		board.changeTurn();
		assertFalse(board.getTurn());
		assertFalse(board.getGreenTurn());
		board.changeTurn();
		assertFalse(board.getGreenTurn());//GreenTurn should never be true!!
	}
	
	@Test
	public void changeTurnTest3TeamNoWinner() {
    	board.initialize("src/names.txt", false);
		assertTrue(board.getTurn()); 
		assertFalse(board.getGreenTurn());  // red team first
		board.changeTurn();
		assertFalse(board.getTurn());
		assertFalse(board.getGreenTurn());  // blue team
		board.changeTurn();
		assertTrue(board.getGreenTurn());  // green team
		board.changeTurn();
		assertTrue(board.getTurn()); 
		assertFalse(board.getGreenTurn());  // red team
	}
	
	@Test
	public void changeTurnTest3TeamRedFirstOut() {
    	board.initialize("src/names.txt", true);
		board.changeTurn();                 // red team reveals the first Assassin, change to blue team's turn
		board.setTeamFirstOut(Red);
		assertFalse(board.getTurn()); 
		assertFalse(board.getGreenTurn());  // blue team
		board.changeTurn();
		assertTrue(board.getGreenTurn());  // green team
		board.changeTurn();
		assertFalse(board.getTurn()); 
		assertFalse(board.getGreenTurn());  // blue team
		board.changeTurn();
		assertTrue(board.getGreenTurn());  // green team
	}
	
	@Test
	public void changeTurnTest3TeamBlueFirstOut() { 
    	board.initialize("src/names.txt", false);
		board.changeTurn();
		assertFalse(board.getTurn()); 
		assertFalse(board.getGreenTurn());  // blue team
		board.changeTurn();                 // blue team reveals the first Assassin, change to green team's turn
		board.setTeamFirstOut(Blue);
		assertTrue(board.getGreenTurn());  // green team
		board.changeTurn();
		assertTrue(board.getTurn()); 
		assertFalse(board.getGreenTurn());  // red team
		board.changeTurn();
		assertTrue(board.getGreenTurn());  // green team
		board.changeTurn();
		assertTrue(board.getTurn()); 
		assertFalse(board.getGreenTurn());  // red team
	}
	
	@Test
	public void changeTurnTest3TeamGreenFirstOut() { 
    	board.initialize("src/names.txt", true);
		board.setTeamFirstOut(Green);      // green team reveals the first Assassin, change to red team's turn
		assertTrue(board.getTurn()); 
		assertFalse(board.getGreenTurn());  // red team
		board.changeTurn();
		assertFalse(board.getTurn()); 
		assertFalse(board.getGreenTurn());  // blue team
		board.changeTurn();
		assertTrue(board.getTurn()); 
		assertFalse(board.getGreenTurn());  // red team
		board.changeTurn();
		assertFalse(board.getTurn()); 
		assertFalse(board.getGreenTurn());  // blue team
	}

	/// Location Testers 
		@Test 
		public void getcodenametest() {
			Location locationtest = new Location("Coolguy",1);
			assertEquals("Coolguy",locationtest.getCodename());
			
		}
		@Test
		public void getidtest(){
			Location testtwo  = new Location ("Codeanem",1);
			assertEquals(1,testtwo.getId());
		}
			@Test
			public void foundtest() {
				Location testthree  = new Location("Codename",1);
				assertFalse(testthree.getfound());
				assertTrue(testthree.chnagefound());
			}
			
			
			
		}
	
