package GUI;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import GUI.GUI;

public class Driver implements Runnable {
	/** A JFrame to show message. */
	private JFrame _messageWindow;
	/** A JFrame used for skymaster to enter clue and count. */
	private JFrame _clueWindow;
	/** A JFrame used as main window including menu, display of clue, count and score, 25 buttons and skip turn button. */
	private JFrame _codenamesWindow;
	
	@Override
	public void run() {
		_messageWindow  = new JFrame("Message");
		JPanel messagePanel = new JPanel();
		_messageWindow.getContentPane().add(messagePanel);
		
		_clueWindow = new JFrame("Clue");
		JPanel cluePanel = new JPanel();
		_clueWindow.getContentPane().add(cluePanel);
		
		_codenamesWindow = new JFrame("Codenames");		
		JPanel codenamesPanel = new JPanel();
		JPanel gbCluePanel = new JPanel();
		_codenamesWindow.getContentPane().add(gbCluePanel);
		_codenamesWindow.getContentPane().add(codenamesPanel);
				
		new GUI(messagePanel, cluePanel, gbCluePanel, codenamesPanel, this);
		
		frameBasics(_messageWindow);	
		frameBasics(_clueWindow);	
		frameBasics(_codenamesWindow);	
		
		_messageWindow.setVisible(false);
		_codenamesWindow.setResizable(false);
	}
	
	public void updateJFrame() {
		frameUpdate(_messageWindow);
		frameUpdate(_clueWindow);
		frameUpdate(_codenamesWindow);
	}

	public void frameBasics(JFrame f) {
		f.setVisible(true);
		f.pack();
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
	}
	
	public void frameUpdate(JFrame f) {
		f.pack();
		f.repaint();
	}
	
	public JFrame getCodenamesWindow(){
		return _codenamesWindow;
	}
	
	public JFrame getMessageWindow(){
		return _messageWindow;
	}
	
	public JFrame getClueWindow(){
		return _clueWindow;
	}
	
	
	public static void main(String [] args) {	
		SwingUtilities.invokeLater(new Driver());
	}
}
