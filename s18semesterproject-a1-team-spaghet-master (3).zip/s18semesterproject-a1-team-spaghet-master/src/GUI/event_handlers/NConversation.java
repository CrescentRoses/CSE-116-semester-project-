package GUI.event_handlers;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import GUI.GUI;

public class NConversation implements ActionListener {
	/** Refers to present GUI instance. */
	private GUI _g;
	private String _s;
	private boolean _b;
	
	public NConversation(GUI g, String s, boolean b) {
		_g = g;
		_s = s;
		_b = b;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		_g.messagePanelUpdate();
		_g.conversation2(_s);
		_g.setCurse(_b);
		
	}

}
