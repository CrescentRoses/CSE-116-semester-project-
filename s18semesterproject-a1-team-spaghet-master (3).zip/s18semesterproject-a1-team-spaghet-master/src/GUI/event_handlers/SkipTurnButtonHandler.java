package GUI.event_handlers;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import GUI.GUI;
import code.Board;

public class SkipTurnButtonHandler implements ActionListener {
	/** Refers to present GUI instance. */
	private GUI _g;
	/** A Board instance control the logic of this game. */
	private Board _b;
	
	/**
	 * @param g - an instance variable of type GUI, which accesses the GUI class so that we are able to check the conditions to check the clue
	 */

	public SkipTurnButtonHandler(GUI g, Board b) {
		_g = g;
		_b =b;
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub]
    	_b.changeTurn();
		_g.changeTurn();
		
	}

}
