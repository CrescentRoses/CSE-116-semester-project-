package GUI.event_handlers;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import GUI.GUI;

public class HConversation implements ActionListener {
	/** Refers to present GUI instance. */
	private GUI _g;
	private String _s;
	private JButton _b;
	
	public HConversation(GUI g, String s, JButton b) {
		_g = g;
		_s = s;
		_b = b;
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		_g.messagePanelUpdate();
		_g.conversation2(_s);
		_g.setDis(true);
		_b.getParent().remove(_b);
		_g.getMess().setVisible(true);
		_g.getMess().setSize(800, 600);
		_g.setLord(false);
	}

}
