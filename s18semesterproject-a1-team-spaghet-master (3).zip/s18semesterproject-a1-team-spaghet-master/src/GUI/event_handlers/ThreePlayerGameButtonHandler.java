package GUI.event_handlers;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import GUI.GUI;

public class ThreePlayerGameButtonHandler implements ActionListener{
	
	/** Refers to present GUI instance. */
	private GUI _gui;
	
	public ThreePlayerGameButtonHandler(GUI gui) {
		_gui = gui;
	}
	
    @Override
	public void actionPerformed(ActionEvent e) {
		_gui.restart(false);
	}
	
}