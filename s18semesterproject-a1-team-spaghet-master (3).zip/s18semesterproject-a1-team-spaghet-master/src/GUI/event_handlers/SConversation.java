package GUI.event_handlers;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import GUI.GUI;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;

public class SConversation implements ActionListener {
	/** Refers to present GUI instance. */
	private GUI _g;
	private String _s;
	private boolean _b;
	
	public SConversation(GUI g, String s, boolean b) {
		_g = g;
		_s = s;
		_b = b;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub]
		_g.messagePanelUpdate();
		_g.conversation2(_s);
		_g.setCurse(_b);
		_g.setLord(true);
		try {
		     FileInputStream laugh = new FileInputStream("Laugh.mp3");
		     Player player = new Player(laugh);
		     player.play();
		     } catch (FileNotFoundException e1) {
			e1.printStackTrace();
		     }catch (JavaLayerException e2) {
			e2.printStackTrace();
	        }
	}
}
