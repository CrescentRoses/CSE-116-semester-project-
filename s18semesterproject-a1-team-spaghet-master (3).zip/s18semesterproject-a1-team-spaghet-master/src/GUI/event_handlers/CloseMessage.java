package GUI.event_handlers;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import GUI.GUI;

public class CloseMessage implements ActionListener {
	/** Refers to present GUI instance. */
	private GUI _g;
	
	/**
	 * @param g - an instance of type GUI, which access the GUI class so that we know when to close the message
	 */
	public CloseMessage(GUI g) {
		_g = g;
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		_g.closeMessagePanel();
		
	}

}
