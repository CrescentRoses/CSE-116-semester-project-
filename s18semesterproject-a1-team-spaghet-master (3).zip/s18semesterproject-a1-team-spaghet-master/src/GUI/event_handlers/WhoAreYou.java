package GUI.event_handlers;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import GUI.GUI;

public class WhoAreYou implements ActionListener {
	/** Refers to present GUI instance. */
	private GUI _g;
	private String _s;
	
	public WhoAreYou(GUI g, String s) {
		_g = g;
		_s = s;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		_g.messagePanelUpdate();
		_g.conversation1(_s);
		
	}

}
