package GUI.event_handlers;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import GUI.GUI;
import code.Board;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;


public class BadChoice implements ActionListener {
	/** Refers to present GUI instance. */
	private GUI _g;
	/** A Board instance control the logic of this game. */
	private Board _b;
	
	public BadChoice(GUI g, Board b) {
		_g = g;
		_b = b;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		_g.messagePanelUpdate();
		boolean a = _b.getTurn();
		boolean g = _b.getGreenTurn();
		int i = g ? 12 : a ? 10 : 11;
		_g.showMessageIfWin(i);
		try {
			FileInputStream badchoice = new FileInputStream("BadChoice.mp3");
			Player player = new Player(badchoice);
			player.play();
			} catch (FileNotFoundException e1) {
    			e1.printStackTrace();
    		}catch (JavaLayerException e2) {
    			e2.printStackTrace();
    	    }        
	}

}
