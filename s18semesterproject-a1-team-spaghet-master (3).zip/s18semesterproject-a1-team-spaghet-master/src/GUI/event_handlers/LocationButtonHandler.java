package GUI.event_handlers;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import GUI.GUI;
import code.Board;

public class LocationButtonHandler implements ActionListener{
	/** A Board instance control the logic of this game. */
	private Board _board;
	/** Refers to present GUI instance. */
	private GUI _gui;
	/** A button used to display Location. */
	private JButton _btn;
	/** The row number of the button in 5x5 grid. */
	private int _row;
	/** The column number of the button in 5x5 grid. */
	private int _col;
	
	/**
	 * @param b - instance of the board class
	 * @param gui - instance of the GUI class
	 * @param button - a button which is needed to edit and change the appearance of the button.
	 * @param i - an int type variable that refers to each row
	 * @param j - an int type variable that refers to each column
	 */
	public LocationButtonHandler(Board b,GUI gui, JButton button, int i, int j) {
		_board = b;
		_gui = gui;
		_btn = button;
		_row = i;
		_col = j;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		boolean turnBefore = _board.getTurn();
		boolean greenTurnBefore = _board.getGreenTurn();
		int person = _board.revealALocation(_row, _col);
		// change the appearance of button
		_btn.setText("");
		_gui.setLocationColor(_btn, person);
		_btn.setEnabled(false); // can not select again

		//update _cluecount panel	
	    _gui.cluecountPanelUpdate();
		//update _score panel
		_gui.redScore();
		_gui.blueScore();
		if(_board.getHasGreen())
			_gui.greenScore();
		
		// check board status
		int status = _board.checkBoardState();
		boolean win = _gui.showMessageIfWin(status);
		
		// if the turn changes after reveal a location
		if((turnBefore != _board.getTurn() || greenTurnBefore != _board.getGreenTurn()) && !win) {
			_board.setClueAndCount("", 0);
			_gui.changeTurn();
		}
	}

}
