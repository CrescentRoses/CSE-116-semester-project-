	package GUI;
	
	import java.awt.BorderLayout;
	import java.awt.Color;
	import java.awt.Dimension;
	import java.awt.Font;
	import java.awt.GridBagLayout;
	import java.awt.GridLayout;
	import java.util.ArrayList;
	import java.util.Random;
	
	import javax.swing.BoxLayout;
	import javax.swing.ImageIcon;
	import javax.swing.JButton;
	import javax.swing.JLabel;
	import javax.swing.JFrame;
	import javax.swing.JMenu;
	import javax.swing.JMenuBar;
	import javax.swing.JMenuItem;
	import javax.swing.JPanel;
	import javax.swing.JTextField;
	import javax.swing.Timer;
	import javax.swing.SwingConstants;
	
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	
	import javazoom.jl.decoder.JavaLayerException;
	import javazoom.jl.player.Player;
	
	import GUI.event_handlers.LocationButtonHandler;
	import GUI.event_handlers.TimerHandler;
	import GUI.event_handlers.TwoPlayerGameButtonHandler;
	import GUI.event_handlers.CheckClue;
	import GUI.event_handlers.CloseMessage;
	import GUI.event_handlers.Exit;
	import GUI.event_handlers.MConversation;
	import GUI.event_handlers.NConversation;
	import GUI.event_handlers.WhoAreYou;
	import GUI.event_handlers.BadChoice;
	import GUI.event_handlers.HConversation;
	import GUI.event_handlers.SConversation;
	import GUI.event_handlers.SkipTurnButtonHandler;
	import GUI.event_handlers.ThreePlayerGameButtonHandler;
	import code.Board;
	import code.Location;
	import code.Observer;
	
	public class GUI implements Observer{
		/** A Board instance control the logic of this game. */
		private Board _board;   
		/** A Driver instance giving access to JFrame. */
		private Driver _windowHolder;
		/** A Panel holding children panels including a File meun,{@link#_cluecount},{@link#_scorePanel},{@link#_gameboard} and {@link#_skipturn}.*/
		private JPanel _codename;
		/** A Panel holding labels including {@link#_cluemenu},{@link#_counter}. */
		private JPanel _cluecount;
		/** A Panel holding labels including {@link#_redscoreLabel},{@link#_bluescoreLabel}. */
		private JPanel _scorePanel;
		/** A Panel holding 25 buttons {@link#_locBtns}. */
		private JPanel _gameboard; 
		/** A Panel holding a button {@link#_turnskip}. */
		private JPanel _skipturn;
	   /** A Panel used for displaying all messages.*/
		private JPanel _message;
	   /** A Panel contained in {@link Driver#_clueWindow} and used for entering clue and count.*/
		private JPanel _clueinput;
	   /** A text message Panel contained in {@link#_message}.*/
		private JPanel _word; 
	   /** A button Panel contained in {@link#_message}.*/
		private JPanel _button; 
		
	   /** A textfield for entering clue.*/
		private JTextField _clue; 
	   /** A textfield for entering count.*/
		private JTextField _count; 
	
		/** A Label indicates the textfield {@link#_clue} to enter clue. */
		private JLabel _cluecheck; 
		/** A Label indicates the textfield {@link#_count} to enter count. */
		private JLabel _countercheck;
		/** A Label displaying the clue given by spymaster. */
		private JLabel _cluemenu;
		/** A Label displaying the remaining count. */
		private JLabel _counter;
		/** A Label displaying how many red agents have been revealed. */
		private JLabel _redscoreLabel;
		/** A Label displaying how many blue agents have been revealed. */
		private JLabel _bluescoreLabel;
		/** A Label displaying how many green agents have been revealed. */
		private JLabel _greenscoreLabel;
		/** A Label displaying messages in messageWindow. */
		private JLabel _m;
		/** A Label displaying which team is in its turn. */
		private JLabel _turn;
		/** A Label displaying a image when Assassin is revealed. */
		private JLabel _imageLabel;
		
		private JPanel imagePanel;
	
		/** A Button used to skip present turn. */
		private JButton _turnskip;
		/** A Button used to check the legality of clue and count. */
		private JButton _checkclue;
		/** A Button used to close message window. */
		private JButton _closeMessage;
		/** A Button in message window,which is used to restart a new 2-team game. */
		private JButton _restart2Team;
		/** A Button in message window,which is used to restart a new 3-team game. */
		private JButton _restart3Team;
		/** A Array of 25 buttons, which is used to display the codename and identity (Blue Agent/Red Agent/Assassin/Innocent Bystander). */
		private JButton[][] _locBtns;
		private boolean loserHappen;
		
		/** A field related to the easter egg written by Tianyu. */
		private int redIll;
		/** A field related to the easter egg written by Tianyu. */
		private int blueIll;
		/** A field related to the easter egg written by Tianyu. */
		private int greenIll;
		/** A field related to the easter egg written by Tianyu. */
		private boolean devil;
		/** A field related to the easter egg written by Tianyu. */
		private boolean curse;
		/** A field related to the easter egg written by Tianyu. */
		private boolean gcurse;
		/** A field related to the easter egg written by Tianyu. */
		private int curseNum;
		/** A field related to the easter egg written by Tianyu. */
		private JButton c1;
		/** A field related to the easter egg written by Tianyu. */
		private boolean lord;
		/** A field related to the easter egg written by Tianyu. */
		private boolean dis;
		/** A field related to the easter egg written by Tianyu. */
		private JButton disable;
		/** A field related to the easter egg written by Tianyu. */
		private boolean  happen;
		
	
		/** Whether the easter egg written by Rui has been found. */
		private boolean _foundEasterEgg;
		/** A Timer used to control the hint time in the easter egg written by Rui . */
		private Timer _timer;
		
		/**
	     * Creates a new GUI and start a new game.
		 *
	     * @param messagePanel Panel used for displaying all messages.
	     * @param cluePanel Panel used to enter clue and count.
	     * @param gbCluePanel Panel used to display clue and remaining count.
	     * @param codenamePanel Panel used to display File menu, ,{@link#_cluecount},{@link#_scorePanel},{@link#_gameboard} and {@link#_skipturn}.
	     * @param driver Driver providing access to JFrame.
	     */
		public GUI(JPanel messagePanel, JPanel cluePanel, JPanel gbCluePanel, JPanel codenamePanel, Driver driver) {
		    _message = messagePanel;
			_clueinput = cluePanel;
			_cluecount = gbCluePanel;
			_codename = codenamePanel;
			_windowHolder = driver; 
			
			restart(false);
		}
		
		/**
	     * Initialize a new game.
	     */
		public void restart(Boolean version) {
			_board = new Board();
			_board.initialize("src/names.txt",version);
			// Initialize the fields of easter egg written by Tianyu.
			devil = false;
			redIll = 0;   
			blueIll = 0; 
			lord = false;
			dis = false;
			happen = false;
			gcurse = false;
			curseNum = 0;
			//Initialize the fields of easter egg written by Rui.
			_foundEasterEgg = false;
			//initialize the _clueinput panel
			cluePanel();
			//initialize the _message panel
			_message.removeAll();
			_message.setLayout(new BoxLayout(_message, BoxLayout.Y_AXIS));
			loserHappen = false;
			imagePanel = new JPanel();
			_imageLabel = new JLabel();
			imagePanel.add(_imageLabel);
			_message.add(imagePanel);
			
			_word = new JPanel(new GridBagLayout());
		    _button = new JPanel();
		    _button.setLayout(new BoxLayout(_button, BoxLayout.Y_AXIS));
			_message.setBackground(Color.WHITE);
			_word.setBackground(Color.WHITE);
			_button.setBackground(Color.WHITE);
			_message.add(_word);
			_message.add(_button);
			_clueinput.setLayout(new BoxLayout(_clueinput, BoxLayout.Y_AXIS));
			//initialize the _codename panel
			_codename.removeAll();
			_codename.setLayout(new BoxLayout(_codename,BoxLayout.Y_AXIS));
			JPanel menuPanel = new JPanel();
			_codename.add(menuPanel);
			menuPanel.setLayout(new BorderLayout());
			JMenuBar menubar = new JMenuBar();
			menuPanel.add(menubar,BorderLayout.NORTH);
			JMenu file = new JMenu("File");
			menubar.add(file);
			JMenuItem exit = new JMenuItem("Exit");
			JMenuItem newGame1 = new JMenuItem("2-team game");
			JMenuItem newGame2 = new JMenuItem("3-team game");
			file.add(exit);
			file.add(newGame1);
			file.add(newGame2);
			exit.addActionListener(new Exit());
			newGame1.addActionListener(new TwoPlayerGameButtonHandler(this));   // I move previous code to TwoPlayerGameButtonHandler
			newGame2.addActionListener(new ThreePlayerGameButtonHandler(this)); // I move previous code to TPlayerGameButtonHandler
	
			//initialize clue and count panel in codenames window
			cluecountPanelUpdate();
			_cluecount.setLayout(new BoxLayout(_cluecount, BoxLayout.Y_AXIS));
			_codename.add(_cluecount);
			//initialize red and blue team score in codenames window
			_scorePanel = new JPanel();
			_redscoreLabel = new JLabel("Red: " + _board.getRedcount());
			_bluescoreLabel = new JLabel("Blue: " + _board.getBluecount());
			_redscoreLabel.setFont(new Font("Serif", Font.PLAIN, 20));
			_bluescoreLabel.setFont(new Font("Serif", Font.PLAIN, 20));
			_scorePanel.add(_redscoreLabel);
			_scorePanel.add(_bluescoreLabel);
			//if it's 3team
			if(_board.getHasGreen()) {
				_greenscoreLabel = new JLabel("Green: " + _board.getGreencount());
				_greenscoreLabel.setFont(new Font("Serif", Font.PLAIN, 20));
				_scorePanel.add(_greenscoreLabel);
			}
			_scorePanel.setLayout(new BoxLayout(_scorePanel, BoxLayout.Y_AXIS));
			_codename.add(_scorePanel);
			// initialize the JPanel _gameboard that has a grid layout to hold 5x5 buttons
			_gameboard = new JPanel();
			_gameboard.setLayout(new GridLayout(5,5));	
			_codename.add(_gameboard);
			boardInSkyMasterTurn();
			//initialize end turn button
			_skipturn = new JPanel();
			_turnskip = new JButton("End Turn");
			_turnskip.addActionListener(new SkipTurnButtonHandler(this,_board));
			setButton(_turnskip);
			_skipturn.add(_turnskip);
			_codename.add(_skipturn);	
			//At the beginning, the clue window and codename window are enabled
			_windowHolder.getClueWindow().setEnabled(true);
			_windowHolder.getCodenamesWindow().setEnabled(true);
			_windowHolder.getMessageWindow().setVisible(false); 
			
			update();
		}
		
		public void redScore() {
			_redscoreLabel.setText("Red: " +_board.getRedcount());
			update();
		}
		
		public void blueScore() {
			_bluescoreLabel.setText("Blue: " +_board.getBluecount());
			update();
		}
		
		public void greenScore() {
			_greenscoreLabel.setText("Green: " +_board.getGreencount());
			update();
		}
		
		/**
		 * Updates {@link #_message} panel by using a given message "a". Disable other windows 
		 * if message window has not been close.
		 * 
		 * @param a - the given message that will update the message window.
		 */
		public void messagePanel1(String a) {
		    messagePanelUpdate();
			update();
			_windowHolder.getMessageWindow().setSize(600, 200);
			_m = new JLabel(a);
			_word.add(_m);
			//When a message window is shown, disable clue window and codename window.
			_windowHolder.getClueWindow().setEnabled(false);
			_windowHolder.getCodenamesWindow().setEnabled(false);
		}
		
		/**
		 * Update message window if assassin has been revealed. Special songs(selected by Andres) will be played when assassin is revealed.<br>
		 * And an message with a restart button will pop up after that.
		 */
		public void messagePanelAssassin() {
			messagePanelUpdate();
			ArrayList<String> assassin = new ArrayList<String>();
			assassin.add("Nothing is ture. Everything is permitted."); //See The Creed's Maxim 
			assassin.add("We are the architects of our actions, and that we must live with their consequences, whether glorious or tragic."); //The current mentor, grand mater of The Botherhood. 
			assassin.add("YOU JUST LOST THE GAME IDIOT! TRY NOT TO SHOOT IN THE DARK NEXT TIME!");//Joke
			assassin.add("You people are not innocent."); //See the first tenet of The Creed's Maxim 
			assassin.add("Beware the ides of March."); //Soothsayer from "Julius Caesar"(Act I, Scene 2) by William Shakespear.
	
	 			ImageIcon image = new ImageIcon("JuliasEasterEgg.jpg");
	 			_imageLabel = new JLabel();
	 			_imageLabel.setIcon(image);
	 			imagePanel.add(_imageLabel);
				Random rand = new Random();
				int  n = rand.nextInt(5); 
				if(n != 1 && n != 2) {
					_m = new JLabel(assassin.get(n));
				}
				else if(n == 1) {
					_m = new JLabel("<html><center>" + assassin.get(n).substring(0, 42) + "<br>" + assassin.get(n).substring(42, 83) + "<br>" + assassin.get(n).substring(83, 112) + "</center></html>");
				}
				else if(n == 2) {
					_m = new JLabel("<html><center>" + assassin.get(n).substring(0, 30) + "<br>" + assassin.get(n).substring(30, 68) + "</center></html>");
				}
				
			_word.add(_m);
			_windowHolder.getMessageWindow().setSize(750, 300);
		    _m.setForeground(Color.black);
			_m.setFont(new Font("Serif", Font.ITALIC, 28));
	            if(_board.getStatus() == 4 || _board.getStatus() == 5 || _board.getStatus() == 6) {
			_closeMessage = new JButton("close");
		        _closeMessage.addActionListener(new CloseMessage(this));
	                setButton(_closeMessage);
	                _button.add(_closeMessage);
	                System.out.println("state: " + _board.getStatus());
		    }
			//disable other windows
			_windowHolder.getClueWindow().setEnabled(false);
			_windowHolder.getCodenamesWindow().setEnabled(false);
		}
		
		/**
		 * Special songs(selected by Andrew) will be played when we have a normal winner.<br>
		 * And prevailing message will be poped up after that. 
		 */
		public void messagePanelNormalWin() {
			messagePanelUpdate();
			if(_board.getStatus() == 1) {
				_m = new JLabel("Red team wins!");
				_m.setForeground(Color.red);
	    		_m.setFont(new Font("SansSerif", Font.ITALIC, 36));
	    		// Sound implementation
		        try {
		    		FileInputStream fileInputStream = new FileInputStream("redsound.mp3");
		    		Player player = new Player(fileInputStream);
		    		player.play();
		    		} catch (FileNotFoundException e) {
		    			e.printStackTrace();
		    		}catch (JavaLayerException e) {
		    			e.printStackTrace();
		    		}
			}
			if(_board.getStatus() == 2) {
				_m = new JLabel("Blue team wins!");
			    _m.setForeground(Color.blue);
	            _m.setFont(new Font("SansSerif", Font.ITALIC, 36));
	            // sound Implentation 
		        try {
		    		FileInputStream fileInputStream = new FileInputStream("bluesound.mp3");
		    		Player player = new Player(fileInputStream);
		    		player.play();
		    		} catch (FileNotFoundException e) {
		    			e.printStackTrace();
		    		}catch (JavaLayerException e) {
		    			e.printStackTrace();
		    	    }
			    }
			if(_board.getStatus() == 3) {
				_m = new JLabel("Green team wins!");
			    _m.setForeground(Color.green);
	            _m.setFont(new Font("SansSerif", Font.ITALIC, 36));
	            // sound Implentation
	            try {
		    		FileInputStream fileInputStream = new FileInputStream("greensound.mp3");
		    		Player player = new Player(fileInputStream);
		    		player.play();
		    		} catch (FileNotFoundException e) {
		    			e.printStackTrace();
		    		}catch (JavaLayerException e) {
		    			e.printStackTrace();
		    	    }
	
			    }
			
			_word.add(_m);
			_windowHolder.getMessageWindow().setSize(500, 200);
			//disable other windows
			_windowHolder.getClueWindow().setEnabled(false);
			_windowHolder.getCodenamesWindow().setEnabled(false);
		}
		
		/**
		 * Updates the messagePanel when the win status is given
		 * 
		 * @param status - 
		 * <ul> 
	         *       <li>0 no winner, no loser</li>
		 *	 <li>1 red team wins </li>
		 *       <li>2 blue team wins</li>
		 *	 <li>3 green team wins  </li>
		 *	 <li>4 red team loses, no winner, turn is always false</li>
	  	 *	 <li>5 blue team loses, no winner, turn always true</li>
	  	 *	 <li>6 green team loses, no winner, greenTurn always false</li>
		 *	 <li>7 assassins revealed, red win</li>
		 *	 <li>8 assassins revealed, blue win</li>
		 *	 <li>9 assassins revealeed, green win</li>
		 * </ul>
		 * @return {@code true} if we have a winner, {@code false} otherwise.
		 */
		public boolean showMessageIfWin(int status) {
		        _restart2Team = new JButton("Start a new 2-team game");
			_restart2Team.addActionListener(new TwoPlayerGameButtonHandler(this));
			setButton(_restart2Team);
		        _restart3Team = new JButton("Start a new 3-team game");
			_restart3Team.addActionListener(new ThreePlayerGameButtonHandler(this));
			setButton(_restart3Team);
		        boolean retVal = false;
			if((status == 4 || status == 5 || status == 6) && !loserHappen) {
				messagePanelAssassin();
				_windowHolder.getCodenamesWindow().setEnabled(false);
				_windowHolder.getMessageWindow().setVisible(true);
				loserHappen = true;
			}
			else if(status == 7 || status == 8 || status == 9) {
				messagePanelAssassin();
				_windowHolder.getCodenamesWindow().setEnabled(false);
				_windowHolder.getMessageWindow().setVisible(true);
				retVal = true;
				_button.add(_restart2Team);
				_button.add(_restart3Team);
			}
			else if(status == 1 || status == 2 || status == 3) {
				messagePanelNormalWin();
			    _windowHolder.getCodenamesWindow().setEnabled(false);
			    _windowHolder.getMessageWindow().setVisible(true);
				retVal = true;
				_button.add(_restart2Team);
				_button.add(_restart3Team);
			}
			else if(status == 10 || status == 11 || status == 12) {
				final String a = "Keep in mind you idiot:";
				_m = new JLabel("<html><center>" + a +"<br>" + "Touch tiger's ass, you die."+ "</center></html>");
				_m.setForeground(status == 10 ? Color.red : status == 11 ? Color.blue : Color.green);
				_m.setFont(new Font("SansSerif", Font.ITALIC, 36));
				update();
				_word.add(_m);
				_windowHolder.getMessageWindow().setSize(950, 500);
			       _windowHolder.getMessageWindow().setVisible(true);
				retVal = false;
				_board.setStatu(status == 10 ? 4 : status == 11 ? 5 : 6);
				_board.setTeamFirstOut(_board.getStatus() == 4 ? 1 : _board.getStatus() == 5 ? 2 : 4);
				_board.changeTurn();
				changeTurn();
				loserHappen = true;
				_closeMessage = new JButton("close");
		                _closeMessage.addActionListener(new CloseMessage(this));
	                         setButton(_closeMessage);
	                        _button.add(_closeMessage);
			}		
			update();
			return retVal;
		}
	
	    /**
	     * Close {@link Driver#_messageWindow}, enable other windows.
	     */
		public void closeMessagePanel() {
			messagePanelUpdate();
			_windowHolder.getMessageWindow().setVisible(false);
			//able the other windows
			_windowHolder.getClueWindow().setEnabled(true);
			_windowHolder.getCodenamesWindow().setEnabled(true);
			_windowHolder.getClueWindow().setVisible(true);
			_windowHolder.getCodenamesWindow().setVisible(true);
		}
			
		/**
		 * Initializes the clue an count input panel
		 */
	    public void cluePanel() {
	    	_clueinput.removeAll();	    
			_checkclue = new JButton("Agree Check");
		    _checkclue.setFont(new Font("Serif", Font.PLAIN, 21));
		    _turn = new JLabel("");
			_cluecheck = new JLabel("Enter your clue, spymaster");
		    _cluecheck.setFont(new Font("SansSerif", Font.PLAIN, 21));
			_countercheck = new JLabel("Enter your number, spymaster");
			_countercheck.setFont(new Font("SansSerif", Font.PLAIN, 21));
			_clue = new JTextField(25);
		    _clue.setFont(new Font("SansSerif", Font.PLAIN, 21));
			_count = new JTextField(25);
			_count.setFont(new Font("SansSerif", Font.PLAIN, 21));
		    _clueinput.add(_turn);
			_clueinput.add(_cluecheck);
			_clueinput.add(_clue);
			_clueinput.add(_countercheck);
			_clueinput.add(_count);
			_clueinput.add(_checkclue);
			_checkclue.addActionListener(new CheckClue(this));		
		}
		
	   /**
	     * Checks whether the clue and count entered by spymaster are legal or not.<br>
	     * <em>There are two exquisite Easter eggs(by Rui and Tianyu) are hidden in this method.</em>   
	     *
	     * @see #asmodeus()
	     * @see #findAnEasterEgg(String, String)
	     */
	    public void clueCheck() {
	    	messagePanelUpdate();
	    	boolean a = true;
	    	//Easter egg 1 part 1 (Tianyu)
	        if(lord == true && _count.getText().equals("Omega") && _clue.getText().equals("Alpha") && !happen) {   		
	        	if(gcurse && _board.getGreenTurn()) lordAo();
	        	else if(!gcurse && curse == _board.getTurn()) lordAo();
	        	else checkIsNumber();
	        }
	    	else{
	    		//easter egg 2 (Rui)
	    		if(_board.checkClue(_clue.getText())) {
	        		redIll = 0;
	        		blueIll = 0;
				greenIll = 0;
	        		boolean b = findAnEasterEgg(_clue.getText(), _count.getText());
	       			if(b) {
	       				_cluemenu.setText("Clue: " + "Easter Egg");
	       				int givenCount = -1;
	       				if(_board.getTurn()) givenCount = 9;
	        		    else givenCount = 8;
	        		    _counter.setText("Count: " + givenCount);
				        _board.setClueAndCount("Easter Egg", givenCount);
	        			boardInTeamTurn();
	        		}
	    			//normal code
	       			else {
	       				if(checkIsNumber()) {
	       					try {
	           			        _board.setClueAndCount(_clue.getText(), Integer.parseInt(_count.getText()));
	           		        }
	           		        catch(IllegalArgumentException e){
	               		        String s = "Count has to be in(0, 25], try again!";
	                            messagePanel1(s);
	    		                _m.setForeground(Color.black);
	               		        _m.setFont(new Font("Helvetica", Font.BOLD, 24));
	           		            _windowHolder.getMessageWindow().setVisible(true);
	               		        _closeMessage = new JButton("close");
	               		        _closeMessage.addActionListener(new CloseMessage(this));
	               		        setButton(_closeMessage);
	            		        _button.add(_closeMessage);
	          		            a = false;
	          		            }
	       				}
	       				else a = false;
	       		        if(a) {
	       			        _cluemenu.setText("Clue: " + _board.getClue());
	       			        _counter.setText(String.valueOf("Count: " +_board.getCount()));
	       			        boardInTeamTurn();
	    		            _clue.setText("");
	       			        _count.setText("");;
	       			        _windowHolder.getMessageWindow().setVisible(false);
	       		        }       
	       		    }
	            }
		        else {
			       if(_board.getGreenTurn()) greenIll++;
		        	else if(_board.getTurn()) redIll++;
			        else blueIll++;
			        //easter egg 1 part 2 (Tianyu)
			         if((redIll >= 3 || blueIll >= 3 || greenIll >= 3) && devil == false) asmodeus();	
			        else {
			        	String s = "Illegal Clue! Try again!";
	    			    messagePanel1(s);
				        _m.setForeground(Color.black);
	        		    _m.setFont(new Font("Helvetica", Font.BOLD, 25));
	    			    _windowHolder.getMessageWindow().setVisible(true);
	        		    _closeMessage = new JButton("close");
	                    _closeMessage.addActionListener(new CloseMessage(this));
	        	        setButton(_closeMessage);
	      		        _button.add(_closeMessage);
	           	        update();
	           	        _windowHolder.getMessageWindow().setSize(380, 150);
	    		   }
		        }
	        }		
	    }
	    	
	    /**
	     * This method ensures that the count entered by the spymaster is an int number.<br>
	     * An error message will show up if spymaster enters anything other than Integer.  
	     * 
	     * @return {@code true} if it is an int. {@code false} otherwise.
	     */
	    public boolean checkIsNumber() {
			try {
				Integer.parseInt(_count.getText());
			}
			catch(NumberFormatException e) {
				String s = "Count has to be an integer number, try again!";
				messagePanel1(s);
				_m.setForeground(Color.black);
	    		_m.setFont(new Font("Helvetica", Font.BOLD, 25));
				_windowHolder.getMessageWindow().setVisible(true);
	            _closeMessage = new JButton("close");
	 	        _closeMessage.addActionListener(new CloseMessage(this));
				setButton(_closeMessage);
				_button.add(_closeMessage);
				return false;
			}
			return true;
	    }
	    
	    /**
	     * Initializes the JPanel {@link#_gameboard} when it is the skymaster's portion.
	     * Revealed Locations only display the color indicating their identity. 
	     * Locations that have NOT been revealed display their codeword and the color indicating their identity.
	     * 
	     * @see #setLocationColor(JButton, int)
	     */
	    public void boardInSkyMasterTurn() {
			_gameboard.removeAll();
		    //make Checkclue window visiable.
			_windowHolder.getClueWindow().setVisible(true);
			
			String turnShown = _board.getGreenTurn() ? "Green Team" : _board.getTurn()? "Red Team" : "Blue Team";
			Color colorShown = _board.getGreenTurn() ? Color.green : _board.getTurn()? Color.red : Color.blue;
	
	        _turn.setText(turnShown);
	        _turn.setFont(new Font("Courier", Font.BOLD, 36));
	        _turn.setForeground(colorShown);
			// instantiate 25 buttons, assign codenames and persons
			_locBtns = new JButton[5][5];
			Location[][] locations = _board.getlocations();
			for(int i = 0; i < 5; i++)
				for(int j = 0; j < 5; j++) {
					JButton btn = new JButton();
					btn.setSize(new Dimension(100,100));
					if(!locations[i][j].getfound()) {
						btn.setText(locations[i][j].getCodename());
					    btn.setFont(new Font("Courier", Font.BOLD, 30));
					}
				    setLocationColor(btn,locations[i][j].getId());
				    btn.setEnabled(false);
					_gameboard.add(btn);
					_locBtns[i][j] = btn;
				}
			update();
	    }
	    
	    /**
	     * Initializes the JPanel {@link#_gameboard} when it is the team's portion.
	     * Revealed Locations only display the color indicating their identity.
	     * Locations that have NOT been revealed ONLY display their codeword.
	     * 
	     * @see #setLocationColor(JButton, int)
	     */
		public void boardInTeamTurn() {
			_gameboard.removeAll();
			//make Checkclue window invisiable.
			_windowHolder.getClueWindow().setVisible(false);
			_windowHolder.getMessageWindow().setVisible(false);
			// instantiate 25 buttons, assign codewords and persons
			_locBtns = new JButton[5][5];
			Location[][] locations = _board.getlocations();
			for(int i = 0; i < 5; i++)
				for(int j = 0; j < 5; j++) {
					JButton btn = new JButton();
					if(!locations[i][j].getfound()) {
						btn.setText(locations[i][j].getCodename());
					    btn.setFont(new Font("Courier", Font.BOLD, 30));
						btn.setBackground(Color.WHITE);
						btn.setForeground(Color.BLACK);
						btn.addActionListener(new LocationButtonHandler(_board,this,btn,i,j));
					}
					else {
						setLocationColor(btn, locations[i][j].getId());
						btn.setEnabled(false);
					}
					_gameboard.add(btn);
					_locBtns[i][j] = btn;
				}
			// Easter egg (Tianyu)
			if(devil && dis == false) {
				if(!_board.getHasGreen() || _board.getStatus() == 6) {
					if(_board.getTurn() == curse) curse();
				}
				else {
					if(curseNum == 1) {
						if(gcurse == true && _board.getGreenTurn()) curse();
						else if(gcurse == false && _board.getTurn() == curse) curse();					
					}
					else if(curseNum == 2) {
						if(gcurse == false) {
							if(!_board.getGreenTurn()) curse();
						}
						else {
							if(_board.getGreenTurn() || _board.getTurn() == curse) curse();
						}
					}            
				}
	
		    }
			update();
		}
			
		/**
		 * For every one of the 25 Location instances, a background color is assigned depend on the value of the person identity.
		 * <h3>Meaning of Color:</h3>
	     * <ul>
		 *     <li> Red - Red Agent </li>
		 *     <li> Blue - Blue Agent </li>
		 *     <li> Yellow - Assassin </li>
		 *     <li> Grey - Innocent Bystander </li> 
		 * </ul>
		 * 
		 * @param btn A button that is set the background color.
		 * @param person Identity of the person at that location instance.
		 */
	    public void setLocationColor(JButton btn, int person) {
	    	if(person == 0)
	    		btn.setBackground(Color.YELLOW);
	    	else if(person == 1)
	    		btn.setBackground(Color.RED);
	    	else if(person == 2)
	    		btn.setBackground(Color.BLUE);
	    	else if(person == 4)
	    		btn.setBackground(Color.GREEN);
	    	else
			    btn.setBackground(Color.GRAY);
	    	    btn.setForeground(Color.BLACK);
	    }
	
		/**
		 * Check whether the easter egg written by Rui has been found. If found, after ten seconds, the codewords and identities
		 * of all 25 locations will be presented for five seconds. Don't miss the chance!
		 * 
		 * @param clue The clue entered by spymaster.
		 * @param count The count entered by spymaster.
		 * @return {@code true} if the easter egg is found. {@code false} otherwise.
		 */
	    public boolean findAnEasterEgg(String clue, String count) {
	    	if(!_foundEasterEgg) {
	        	if(clue.equals("Easter Egg") && count.equals("007")) {
	        		_timer = new Timer(1000, new TimerHandler(this, _board));
	        		_timer.start();
	        		_foundEasterEgg = true;
	            	return true;
	        	}
	    	}
	    	return false;
	    }
		
	    /**
	     * Every time the status of the turn is changed, the game enters a new spymaster's portion.
	     * The {@link#_redscoreLabel} and {@link#_bluescoreLabel} are updated as well.
	     */
	    public void changeTurn() {
	    	cluePanel();
	    	cluecountPanelUpdate();
	    	boardInSkyMasterTurn();
	    }
		
	    /**
	     *  This method removes all contents from {@link#_message} panel which include
	     *  {@link#_word} and {@link#_button} panel.
	     */
	    public void messagePanelUpdate() {
	    	_word.removeAll();
	    	_button.removeAll();
	    	imagePanel.removeAll();
	    }
	    
	    /**
	     *  Update the clue {@link#_cluemenu} and count{@link#_counter} shown to game player.
	     */
	    public void cluecountPanelUpdate() {
	    	_cluecount.removeAll();
			_cluemenu =  new JLabel("Clue: " + _board.getClue());
			_counter = new JLabel("Count: " + _board.getCount());
			_cluemenu.setFont(new Font("Serif", Font.PLAIN, 20));
			_counter.setFont(new Font("Serif", Font.PLAIN, 20));
			_cluecount.add(_cluemenu);
			_cluecount.add(_counter);
	    }
		
	   /**
	    * This method is used for setting button's properties.
	    * 
	    * @param button - The button whose properties needed to be set.
	    */
	    public void setButton(JButton button) {
		button.setFont(new Font("Serif", Font.PLAIN, 21));
		button.setAlignmentX(JButton.CENTER_ALIGNMENT);
	
	    }
		
	    /**
	     * This method is part of Easter egg 1 ({@link #asmodeus()}).
	     * 
	     * @param s - Message that needed be showed up in {@link #_message} panel.
	     */
		public void conversation1(String s) {
			messagePanel1(s);
			_windowHolder.getMessageWindow().setSize(700, 500);
			_m.setForeground(Color.black);
			_m.setFont(new Font("Serif", Font.ITALIC, 27));
			
			JButton deity = new JButton("<html>1.You are Asmodeus! The God of sin!&ensp;</html>");
			deity.setPreferredSize(new Dimension(300, 140));
			deity.setHorizontalAlignment(SwingConstants.LEFT);
			setButton(deity);
			deity.addActionListener(new NConversation(this, "Indeed, You have won my favor. Your enemies will suffer!", false));
			_button.add(deity);
			
			deity = new JButton("<html>2.You are Bhaal! The God of murder and assassination!&ensp;</html>");
			setButton(deity);
			deity.setHorizontalAlignment(SwingConstants.LEFT);
			deity.addActionListener(new NConversation(this, "Wrong!!! Now, face my curse! You deplorable ant!", true));
			_button.add(deity);
			
			
			deity = new JButton("<html>3.I DON'T CARE WHO THE FUCK YOU ARE.</html>");
			deity.addActionListener(new BadChoice(this, _board));
			setButton(deity);
			deity.setHorizontalAlignment(SwingConstants.LEFT);
			_button.add(deity);
			
			deity = new JButton("<html>4.Whaaaat? I don't know.&ensp;</html>");
			setButton(deity);
			deity.setHorizontalAlignment(SwingConstants.LEFT);
			deity.addActionListener(new MConversation(this, "Then, sell me your soul or face my curse!", true));
			_button.add(deity);
		}
		
		/**
		 * This method is part of Easter egg 1 ({@link #asmodeus()}).
		 * 
		 * @param s - Message that needed be showed up in {@link #_message} panel.
		 */
		public void conversation2(String s) {
			messagePanel1(s);
			_windowHolder.getMessageWindow().setSize(700, 500);
			_m.setForeground(Color.black);
			_m.setFont(new Font("Serif", Font.ITALIC, 27));
			_closeMessage = new JButton(" close ");
			_closeMessage.addActionListener(new CloseMessage(this));
			setButton(_closeMessage);
			_button.add(_closeMessage);
		}
		
		/**
		 * This method is part of Easter egg 1 ({@link #asmodeus()}).
		 * 
		 * @param s - Message that needed be showed up in {@link #_message} panel.
		 */
		public void conversation3(String s) {
			messagePanel1(s);
			_windowHolder.getMessageWindow().setSize(700, 500);
			_m.setForeground(Color.black);
			_m.setFont(new Font("Serif", Font.ITALIC, 27));
			JButton j = new JButton("<html>Yes, yes, my lord, my soul is yours!</html>");
			setButton(j);
			j.addActionListener(new NConversation(this, "Good! Your enemies shall suffer!", false));
			_button.add(j);
			j = new JButton("<html>Begone, spawn of darkness!</html>");
			j.addActionListener(new SConversation(this, "(YOU HAVE BEEN CURSED)", true));
			setButton(j);
			_button.add(j);
		}
		
		/**
		 * This method is part of easter egg 1 ({@link #asmodeus()}), it creates an special button in {@link #_clueinput} panel.<br>
		 * Once this special button is clicked, curse will be dispeled, and easter egg 2 ({@link #findAnEasterEgg(String, String)}) will be hinted.  
		 */
		public void lordAo() {
			happen = true;
			disable = new JButton("Help! Lord AO");
			setButton(disable);
			disable.setAlignmentX(JButton.LEFT_ALIGNMENT);
			disable.addActionListener(new HConversation(this, "<html><center> I sense thy prayer, mortal. Asmodeus willeth be chasten'd. <br> Everything shall return to what twas. <br> As a reward for thy heroic, "
	    				+ "hark carefully:<br><mark>\"Let Easter Egg beeth our code, <br>Let 007 beeth thy number. <br>White thereby might be not white, <br>Secret might be no longer secret.\"</mark></center></html>", disable));
			_clueinput.add(disable);
		}
		
	    /**
	     * This Easter egg was designed in honor of famous board game <em>Dungeons & Dragons</em><br>
	     * It create a hidden button in {@link #_message} panel.
	     * 
	     * @see <a href="https://en.wikipedia.org/wiki/Dungeons_%26_Dragons">DnD</a>
	     * @see <a href="http://dnd.wizards.com/">Dungeons & Dragons Offical Website</a>
	     */	
		public void asmodeus() {
			String s = "Read the fine print!!!";
			String s2 = "You foolish mortal.";
		    _windowHolder.getMessageWindow().setVisible(true);
		    _closeMessage = new JButton("close");
	        _closeMessage.addActionListener(new CloseMessage(this));
	        setButton(_closeMessage);
	        _closeMessage.setAlignmentX(JButton.CENTER_ALIGNMENT);
	        _word.removeAll();
	        _m = new JLabel("<html><center>" + "&emsp;&emsp;" + s 
			        + "&emsp;&emsp;" + "<br>" + "&emsp;&emsp;" 
			        + s2 + "&emsp;&emsp;" + "<br>" + "</center></html>");
	        _word.add(_m);
	        _button.add(_closeMessage);
	        _closeMessage.setAlignmentX(JButton.CENTER_ALIGNMENT);
	        _m.setForeground(Color.black);
	        _m.setFont(new Font("Serif", Font.ITALIC, 27));
	        devil = true;
	
	        c1 = new JButton("Who are you?"); //a hidden button
	        setButton(c1);
		    update();   
	        _button.add(c1);
	        c1.setAlignmentX(JButton.CENTER_ALIGNMENT);
	        c1.addActionListener(new WhoAreYou(this, "I'm the lord of the Baator, who am I?"));
		}
		
		/**
		 * This method is part of Easter egg 1 ({@link #asmodeus()}). It would determine which team is cursed.
		 * The final result will be:
		 * <ul>
		 *    <li> curse = true: Red team is cursed.</li>
		 *    <li> curse = false: Blue team is cursed.</li>
		 *    <li> gcurse = true: Green team is cursed.</li>
		 *    <li> gcurse = false: Green tram is not cursed.</li> 
		 * </ul>
		 * 
		 * @param b - {@code true} if the current turn's team is cursed. {@code false} otherwise.
		 */
		public void setCurse(boolean b) {
				if(!_board.getHasGreen() || _board.getStatus() == 6) { //two teams or no green
					curse = _board.getTurn() && b? true : _board.getTurn() && !b? false : !_board.getTurn() && b? false : true;
					gcurse = false;
					curseNum = 1;
				}
				    
				else if(_board.getStatus() == 4) { //no red
					curseNum = 1;
					curse = false;
				    gcurse = _board.getGreenTurn() && b ? true : _board.getGreenTurn() && !b ? false : !_board.getGreenTurn() && b ? false : true;
				}	
				else if(_board.getStatus() == 5) { //no blue
					curseNum = 1;
					curse = true;
					gcurse = _board.getGreenTurn() && b ? true : _board.getGreenTurn() && !b ? false : !_board.getGreenTurn() && b ? false : true;
				}
				else { //three teams
					if(b == true) { //only 1 team is cursed 
						curseNum = 1;
						gcurse = _board.getGreenTurn() ? true : false;
						if(!gcurse)
							curse = _board.getTurn() ? true : false;
					}
					else { // 2 teams are cursed
						curseNum = 2;
						gcurse = _board.getGreenTurn() ? false : true; 
						if(gcurse) {
							curse = _board.getTurn() ? false : true;
						}
					}
				}
		
				
		}
		
		/**
		 * This method is part of Easter egg 1 ({@link #asmodeus()}) and used to open or
		 * close {@link #lordAo()} event.
		 * 
		 * @param b - {@code true} open {@link #lordAo()} event, or {@code false} close it.
		 */
		public void setLord(boolean b) {
			lord = b;
		}
		
		/**
		 * This method is part of Easter egg 1 ({@link #asmodeus()}) and used to remove curse.
		 * 
		 * @param b - {@code true} if curse has been disabled, {@code false} otherwise.
		 */
		public void setDis(boolean b) {
			dis = b;
		}
		
		/**
		 *  This method is part of Easter egg 1 ({@link #asmodeus()}) and used to set curse.
		 */
		public void curse() {
			Location[][] l = _board.getlocations();
			for(int i = 0; i < 5; i++) {
		        for(int j = 0; j < 5; j++) {
			        if(l[i][j].getId() == 0 && !l[i][j].getfound()) {
				        _cluemenu.setText("Clue: " + l[i][j].getCodename());
				        break;
			        }
		        }
	        }   		
	        _counter.setText("Count: 1");
		}
		
		public JFrame getMess() {
			return _windowHolder.getMessageWindow();
		}
		
	    public Timer getTimer() {
	    	return _timer;
	    }
		
	    public JButton[][] getLocButtons(){
	    	return _locBtns;
	    }
		
		@Override
		public void update(){
			updateJFrame();
		}
		public void updateJFrame() {
			if (_windowHolder != null) {
		          _windowHolder.updateJFrame();
			}
		}
		
	
	}
	
